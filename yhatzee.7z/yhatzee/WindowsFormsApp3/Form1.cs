﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        Boolean[] dRoll = { true, true, true, true, true };
        Image[] dice = { Properties.Resources.d1, Properties.Resources.d2, Properties.Resources.d3, Properties.Resources.d4, Properties.Resources.d5, Properties.Resources.d6 };
        Random random = new Random();
        int diceRoll;
        public Form1()
        {
            InitializeComponent();
        }

        private void di1_Click(object sender, EventArgs e)
        {
            if(dRoll[0] == false)
            {
                dRoll[0] = true;
            }
            if(dRoll[0] == true)
            {
                dRoll[0] = false;
            }
        }

        private void di2_Click(object sender, EventArgs e)
        {
            if (dRoll[1] == false)
            {
                dRoll[1] = true;
            }
            if (dRoll[1] == true)
            {
                dRoll[1] = false;
            }
        }

        private void di3_Click(object sender, EventArgs e)
        {
            if (dRoll[2] == false)
            {
                dRoll[2] = true;
            }
            if (dRoll[2] == true)
            {
                dRoll[2] = false;
            }
        }

        private void di4_Click(object sender, EventArgs e)
        {
            if (dRoll[3] == false)
            {
                dRoll[3] = true;
            }
            if (dRoll[3] == true)
            {
                dRoll[3] = false;
            }
        }

        private void di5_Click(object sender, EventArgs e)
        {
            if (dRoll[4] == false)
            {
                dRoll[4] = true;
            }
            if (dRoll[4] == true)
            {
                dRoll[4] = false;
            }
        }

        private void Roll_Click(object sender, EventArgs e)
        {
            if (dRoll[0] == true || dRoll[1] == true || dRoll[2] == true || dRoll[3] == true || dRoll[4] == true)
            {
                diceRoll = random.Next(1, 6);
            }
            if(dRoll[0] == true)
            {
                if(diceRoll == 1)
                {
                    di1.Image = dice[0];
                }
                if (diceRoll == 2)
                {
                    di1.Image = dice[1];
                }
                if (diceRoll == 3)
                {
                    di1.Image = dice[2];
                }
                if (diceRoll == 4)
                {
                    di1.Image = dice[3];
                }
                if (diceRoll == 5)
                {
                    di1.Image = dice[4];
                }
                if (diceRoll == 6)
                {
                    di1.Image = dice[5];
                }
                dRoll[0] = false;
            }
        }
    }
}
    
    

