﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.di1 = new System.Windows.Forms.Button();
            this.di3 = new System.Windows.Forms.Button();
            this.Roll = new System.Windows.Forms.Button();
            this.di5 = new System.Windows.Forms.Button();
            this.di4 = new System.Windows.Forms.Button();
            this.di2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.rollCount = new System.Windows.Forms.Label();
            this.PlayAgain = new System.Windows.Forms.Button();
            this.di4held = new System.Windows.Forms.Button();
            this.di2held = new System.Windows.Forms.Button();
            this.di1held = new System.Windows.Forms.Button();
            this.di5held = new System.Windows.Forms.Button();
            this.di3held = new System.Windows.Forms.Button();
            this.BasicInstruct = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // di1
            // 
            this.di1.Image = global::WindowsFormsApp3.Properties.Resources.d1;
            this.di1.Location = new System.Drawing.Point(72, 442);
            this.di1.Name = "di1";
            this.di1.Size = new System.Drawing.Size(105, 105);
            this.di1.TabIndex = 0;
            this.di1.UseVisualStyleBackColor = true;
            this.di1.Click += new System.EventHandler(this.di1_Click);
            // 
            // di3
            // 
            this.di3.Image = global::WindowsFormsApp3.Properties.Resources.d3;
            this.di3.Location = new System.Drawing.Point(158, 237);
            this.di3.Name = "di3";
            this.di3.Size = new System.Drawing.Size(105, 105);
            this.di3.TabIndex = 1;
            this.di3.UseVisualStyleBackColor = true;
            this.di3.Click += new System.EventHandler(this.di3_Click);
            // 
            // Roll
            // 
            this.Roll.BackColor = System.Drawing.Color.Red;
            this.Roll.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Roll.Location = new System.Drawing.Point(405, 252);
            this.Roll.Name = "Roll";
            this.Roll.Size = new System.Drawing.Size(162, 75);
            this.Roll.TabIndex = 2;
            this.Roll.Text = "ROLL";
            this.Roll.UseVisualStyleBackColor = false;
            this.Roll.Click += new System.EventHandler(this.Roll_Click);
            // 
            // di5
            // 
            this.di5.Image = global::WindowsFormsApp3.Properties.Resources.d5;
            this.di5.Location = new System.Drawing.Point(248, 40);
            this.di5.Name = "di5";
            this.di5.Size = new System.Drawing.Size(105, 105);
            this.di5.TabIndex = 3;
            this.di5.UseVisualStyleBackColor = true;
            this.di5.Click += new System.EventHandler(this.di5_Click);
            // 
            // di4
            // 
            this.di4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.di4.Image = global::WindowsFormsApp3.Properties.Resources.d4;
            this.di4.Location = new System.Drawing.Point(72, 40);
            this.di4.Name = "di4";
            this.di4.Size = new System.Drawing.Size(105, 105);
            this.di4.TabIndex = 4;
            this.di4.UseVisualStyleBackColor = false;
            this.di4.Click += new System.EventHandler(this.di4_Click);
            // 
            // di2
            // 
            this.di2.Image = global::WindowsFormsApp3.Properties.Resources.d2;
            this.di2.Location = new System.Drawing.Point(248, 442);
            this.di2.Name = "di2";
            this.di2.Size = new System.Drawing.Size(105, 105);
            this.di2.TabIndex = 5;
            this.di2.UseVisualStyleBackColor = true;
            this.di2.Click += new System.EventHandler(this.di2_Click);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(648, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(258, 22);
            this.label1.TabIndex = 6;
            this.label1.Text = "TOTAL";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(648, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 22);
            this.label2.TabIndex = 7;
            this.label2.Text = "Ones";
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(777, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 22);
            this.label3.TabIndex = 8;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(648, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 22);
            this.label4.TabIndex = 9;
            this.label4.Text = "Bonus";
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(777, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 22);
            this.label5.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(648, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 22);
            this.label6.TabIndex = 11;
            this.label6.Text = "Total";
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(777, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 22);
            this.label7.TabIndex = 12;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(648, 172);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 22);
            this.label8.TabIndex = 13;
            this.label8.Text = "Sixes";
            // 
            // label9
            // 
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Location = new System.Drawing.Point(777, 150);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 22);
            this.label9.TabIndex = 14;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(648, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(129, 22);
            this.label10.TabIndex = 15;
            this.label10.Text = "Fives";
            // 
            // label11
            // 
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Location = new System.Drawing.Point(777, 128);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 22);
            this.label11.TabIndex = 16;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(648, 128);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(129, 22);
            this.label12.TabIndex = 17;
            this.label12.Text = "Fours";
            // 
            // label13
            // 
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Location = new System.Drawing.Point(777, 106);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(129, 22);
            this.label13.TabIndex = 18;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(648, 106);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(129, 22);
            this.label14.TabIndex = 19;
            this.label14.Text = "Threes";
            // 
            // label15
            // 
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Location = new System.Drawing.Point(777, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(129, 22);
            this.label15.TabIndex = 20;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label16
            // 
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(648, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(129, 22);
            this.label16.TabIndex = 21;
            this.label16.Text = "Twos";
            // 
            // label17
            // 
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Location = new System.Drawing.Point(777, 62);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(129, 22);
            this.label17.TabIndex = 22;
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label18
            // 
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Location = new System.Drawing.Point(777, 392);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(129, 22);
            this.label18.TabIndex = 23;
            // 
            // label19
            // 
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(648, 392);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(129, 22);
            this.label19.TabIndex = 24;
            this.label19.Text = "Total";
            // 
            // label20
            // 
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Location = new System.Drawing.Point(777, 370);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(129, 22);
            this.label20.TabIndex = 25;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label21
            // 
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(648, 370);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(129, 22);
            this.label21.TabIndex = 26;
            this.label21.Text = "YHATZEE";
            // 
            // label22
            // 
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Location = new System.Drawing.Point(777, 348);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(129, 22);
            this.label22.TabIndex = 27;
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label23
            // 
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(648, 348);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(129, 22);
            this.label23.TabIndex = 28;
            this.label23.Text = "Chance";
            // 
            // label24
            // 
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Location = new System.Drawing.Point(777, 326);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(129, 22);
            this.label24.TabIndex = 29;
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label25
            // 
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(648, 326);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(129, 22);
            this.label25.TabIndex = 30;
            this.label25.Text = "Large Straight";
            // 
            // label26
            // 
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Location = new System.Drawing.Point(777, 304);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(129, 22);
            this.label26.TabIndex = 31;
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label27
            // 
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(648, 304);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(129, 22);
            this.label27.TabIndex = 32;
            this.label27.Text = "Small Straight";
            // 
            // label28
            // 
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Location = new System.Drawing.Point(777, 282);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(129, 22);
            this.label28.TabIndex = 33;
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label29
            // 
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(648, 282);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(129, 22);
            this.label29.TabIndex = 34;
            this.label29.Text = "Full house";
            // 
            // label30
            // 
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Location = new System.Drawing.Point(777, 260);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(129, 22);
            this.label30.TabIndex = 35;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label31
            // 
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(648, 260);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(129, 22);
            this.label31.TabIndex = 36;
            this.label31.Text = "Four of a kind";
            // 
            // label32
            // 
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.Location = new System.Drawing.Point(777, 238);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(129, 22);
            this.label32.TabIndex = 37;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label33
            // 
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(648, 238);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(129, 22);
            this.label33.TabIndex = 38;
            this.label33.Text = "Three of a kind";
            // 
            // rollCount
            // 
            this.rollCount.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rollCount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.rollCount.Location = new System.Drawing.Point(405, 216);
            this.rollCount.Name = "rollCount";
            this.rollCount.Size = new System.Drawing.Size(162, 22);
            this.rollCount.TabIndex = 39;
            // 
            // PlayAgain
            // 
            this.PlayAgain.BackColor = System.Drawing.Color.Silver;
            this.PlayAgain.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayAgain.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PlayAgain.Location = new System.Drawing.Point(648, 432);
            this.PlayAgain.Name = "PlayAgain";
            this.PlayAgain.Size = new System.Drawing.Size(257, 80);
            this.PlayAgain.TabIndex = 40;
            this.PlayAgain.Text = "Play Again?";
            this.PlayAgain.UseVisualStyleBackColor = false;
            this.PlayAgain.Click += new System.EventHandler(this.PlayAgain_Click);
            // 
            // di4held
            // 
            this.di4held.Location = new System.Drawing.Point(113, 151);
            this.di4held.Name = "di4held";
            this.di4held.Size = new System.Drawing.Size(24, 23);
            this.di4held.TabIndex = 41;
            this.di4held.UseVisualStyleBackColor = true;
            // 
            // di2held
            // 
            this.di2held.Location = new System.Drawing.Point(287, 553);
            this.di2held.Name = "di2held";
            this.di2held.Size = new System.Drawing.Size(24, 23);
            this.di2held.TabIndex = 42;
            this.di2held.UseVisualStyleBackColor = true;
            // 
            // di1held
            // 
            this.di1held.Location = new System.Drawing.Point(113, 553);
            this.di1held.Name = "di1held";
            this.di1held.Size = new System.Drawing.Size(24, 23);
            this.di1held.TabIndex = 43;
            this.di1held.UseVisualStyleBackColor = true;
            // 
            // di5held
            // 
            this.di5held.Location = new System.Drawing.Point(287, 151);
            this.di5held.Name = "di5held";
            this.di5held.Size = new System.Drawing.Size(24, 23);
            this.di5held.TabIndex = 44;
            this.di5held.UseVisualStyleBackColor = true;
            // 
            // di3held
            // 
            this.di3held.Location = new System.Drawing.Point(203, 348);
            this.di3held.Name = "di3held";
            this.di3held.Size = new System.Drawing.Size(24, 23);
            this.di3held.TabIndex = 45;
            this.di3held.UseVisualStyleBackColor = true;
            // 
            // BasicInstruct
            // 
            this.BasicInstruct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BasicInstruct.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.BasicInstruct.Location = new System.Drawing.Point(359, 9);
            this.BasicInstruct.Name = "BasicInstruct";
            this.BasicInstruct.Size = new System.Drawing.Size(283, 207);
            this.BasicInstruct.TabIndex = 46;
            this.BasicInstruct.Text = resources.GetString("BasicInstruct.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp3.Properties.Resources.maxresdefault;
            this.ClientSize = new System.Drawing.Size(955, 615);
            this.Controls.Add(this.BasicInstruct);
            this.Controls.Add(this.di3held);
            this.Controls.Add(this.di5held);
            this.Controls.Add(this.di1held);
            this.Controls.Add(this.di2held);
            this.Controls.Add(this.di4held);
            this.Controls.Add(this.PlayAgain);
            this.Controls.Add(this.rollCount);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.di2);
            this.Controls.Add(this.di4);
            this.Controls.Add(this.di5);
            this.Controls.Add(this.Roll);
            this.Controls.Add(this.di3);
            this.Controls.Add(this.di1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button di1;
        private System.Windows.Forms.Button di3;
        private System.Windows.Forms.Button Roll;
        private System.Windows.Forms.Button di5;
        private System.Windows.Forms.Button di4;
        private System.Windows.Forms.Button di2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label rollCount;
        private System.Windows.Forms.Button PlayAgain;
        private System.Windows.Forms.Button di4held;
        private System.Windows.Forms.Button di2held;
        private System.Windows.Forms.Button di1held;
        private System.Windows.Forms.Button di5held;
        private System.Windows.Forms.Button di3held;
        private System.Windows.Forms.Label BasicInstruct;
    }
}

