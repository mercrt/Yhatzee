﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
  Yhatzee V1.3
  Hamza Amir
  V1_0
  * dice rolling done
  V1_1
  * one - sixes done, bonus and total for this donce
  V1_2
  * all the other catagories done
  V1_3
  * total and cheat done
  * added restart button
  * added instructions
  * added the thing that shows if the dice is held
  
  FEATURES THAT ARE DONE:
    *contains appropriate commenting
    *appropriate naming conventions of variables and functions
    *contain an array to store the dice values
    *display the dice as images or buttons
    *use a roll function to get new random values
    *have a way of re-rolling the dice values
    *have boolean variables for 3X, 4X, Yahtzee, full house, small run, large run 
    *display a grid to display the scoreboard
    *have a boolean array for dice being held
    *only reroll dice that are not held
    *show the user which dice are hold
    *calculate the 1 to 6s on the on the scoreboard
    *prevent users from rolling the dice more than three times
    *allow users to select a scoring option
    *prevent users from re-selecting score options
    *calculate the 1s to 6s bonus value and sum the totals
    *calculate on the scoreboard for 3X, 4X, Yahtzee
    *calculate the scoring on a small and large straight
    *calculate the scoring for a full  house and chance
    *the game ends appropriately when all turns are used up
    *the game can be reset after the game
    *secret cheat method
    *scoring possibilities are displayed to the user
*/
namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        Boolean[] dRoll = { true, true, true, true, true };//this is the array to store if the dice is held or not
        //this is the array that holds the dice faces
        Image[] dice = { Properties.Resources.d1, Properties.Resources.d2, Properties.Resources.d3, Properties.Resources.d4, Properties.Resources.d5, Properties.Resources.d6 };
        Random random = new Random();//sets up randomization
        int[] diceRoll = { 0, 0, 0, 0, 0 };//stores the values of the dice role
        int roll = 0;//this sets how many times the dice can be roled
        int[] score = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };//this stores all the end scores
        //values means dice values
        int[] tScore = { 0, 0, 0, 0, 0, 0 };//this stores the 3 of a kind values
        int[] fScore = { 0, 0, 0, 0, 0, 0 };//this stores the 4 of a kind values
        int[] cScore = { 0, 0, 0, 0, 0, 0 };//this stores the chance values
        int[] yScore = { 0, 0, 0, 0, 0, 0 };//this stores the yhatzee values
        int[] sScore = { 0, 0, 0, 0, 0, 0 };//this stores the small straight values
        int[] lScore = { 0, 0, 0, 0, 0, 0 };//this stores the large straight values
        int[] hScore = { 0, 0, 0, 0, 0, 0 };//this stores the full house values
        Boolean[] stored = { false, false, false, false, false, false, false, false, false, false, false, false, false };//this is to final set the score once its selected
        Boolean canPressed = false; //this stops more than one scoring option from being pressed, unless the cheat is pressed first, then one option can be selected after
        //init function
        public Form1()
        {
            //initializes program
            InitializeComponent();
            
        }
        //this is dice one and the click events for it
        private void di1_Click(object sender, EventArgs e)
        {
            dRoll[0] = !dRoll[0];//this switches between true and false for the dice
            //if the dice is held it is red if not it is blue
            if(dRoll[0] == false)
            {
                di1held.BackColor = Color.Red;
            }
            else
            {
                di1held.BackColor = Color.Blue;
            }
        }
        //this is dice 2 and its click events
        private void di2_Click(object sender, EventArgs e)
        {
            dRoll[1] = !dRoll[1];//switches between true and false
            //if the dice is held it is red if not it is blue
            if (dRoll[1] == false)
            {
                di2held.BackColor = Color.Red;
            }
            else
            {
                di2held.BackColor = Color.Blue;
            }
        }
        //this is dice 3 and its click events
        private void di3_Click(object sender, EventArgs e)
        {
            dRoll[2] = !dRoll[2];//switches between true and false
            //if the dice is held it is red if not it is blue
            if (dRoll[2] == false)
            {
                di3held.BackColor = Color.Red;
            }
            else
            {
                di3held.BackColor = Color.Blue;
            }
        }
        //this is dice 4 and its click events
        private void di4_Click(object sender, EventArgs e)
        {
            dRoll[3] = !dRoll[3];//switches between true and false
            //if the dice is held it is red if not it is blue
            if (dRoll[3] == false)
            {
                di4held.BackColor = Color.Red;
            }
            else
            {
                di4held.BackColor = Color.Blue;
            }
        }
        //this is dice 5 and its click events
        private void di5_Click(object sender, EventArgs e)
        {
            dRoll[4] = !dRoll[4];//switches between true and false
            //if the dice is held it is red if not it is blue
            if (dRoll[4] == false)
            {
                di5held.BackColor = Color.Red;
            }
            else
            {
                di5held.BackColor = Color.Blue;
            }
        }
        //this is the roll button and its click events
        private void Roll_Click(object sender, EventArgs e)
        {
            //next 5 lines of code set the tiny box under the dice to red to show the dice are held
            di1held.BackColor = Color.Red;
            di2held.BackColor = Color.Red;
            di3held.BackColor = Color.Red;
            di4held.BackColor = Color.Red;
            di5held.BackColor = Color.Red;
            //if one rols has been used display this text(Starts at zero, inclusive)
            if (roll == 0)
            {
                rollCount.Text = "You have used 1 of 3 rolls";
            }
            //if two rolls have been used display this text
            if (roll == 1)
            {
                rollCount.Text = "You have used 2 of 3 rolls";
            }
            //if three rolls have been used display this text
            if (roll == 2)
            {
                rollCount.Text = "You have used 3 of 3 rolls";
            }
            canPressed = true;//sets all the labels to be able to be pressed
            //the following code will run if less than 2 rolls have been used(starts at zero, inclusive)
            if (roll <= 2)
            {
                roll++;//adds one to the roll counter
                //if the dice is not held
                if (dRoll[0] == true)
                {
                    diceRoll[0] = random.Next(1, 7);//roll the dice
                    //if the roll is one sets the die face to one
                    if (diceRoll[0] == 1)
                    {
                        di1.Image = dice[0];
                    }
                    //if the roll is 2 sets dice face to 2
                    if (diceRoll[0] == 2)
                    {
                        di1.Image = dice[1];
                    }
                    //if the roll is 3 sets dice face to 3
                    if (diceRoll[0] == 3)
                    {
                        di1.Image = dice[2];
                    }
                    //if the roll is 4 sets the dice face to 4
                    if (diceRoll[0] == 4)
                    {
                        di1.Image = dice[3];
                    }
                    //if the roll is 5 sets the dice face to 5
                    if (diceRoll[0] == 5)
                    {
                        di1.Image = dice[4];
                    }
                    //if the roll is 6 sets the dice face to six
                    if (diceRoll[0] == 6)
                    {
                        di1.Image = dice[5];
                    }
                    dRoll[0] = false;//sets the roll for the first dice to false
                }
                //if the dice is not held
                if (dRoll[1] == true)
                {
                    diceRoll[1] = random.Next(1, 7);//rolls dice
                    //sets dice face to 1
                    if (diceRoll[1] == 1)
                    {
                        di2.Image = dice[0];
                    }
                    //sets dice face to 2
                    if (diceRoll[1] == 2)
                    {
                        di2.Image = dice[1];
                    }
                    //sets dice face to 3
                    if (diceRoll[1] == 3)
                    {
                        di2.Image = dice[2];
                    }
                    //sets dice face to 4
                    if (diceRoll[1] == 4)
                    {
                        di2.Image = dice[3];
                    }
                    //sets dice face to 5
                    if (diceRoll[1] == 5)
                    {
                        di2.Image = dice[4];
                    }
                    //sets dice face to 6
                    if (diceRoll[1] == 6)
                    {
                        di2.Image = dice[5];
                    }
                    dRoll[1] = false;//sets the roll if statement false
                }
                //if the dice is not held
                if (dRoll[2] == true)
                {
                    diceRoll[2] = random.Next(1, 7);//rolls the dice
                     //sets dice face to 1
                    if (diceRoll[2] == 1)
                    {
                        di3.Image = dice[0];
                    }
                    //sets dice face to 2
                    if (diceRoll[2] == 2)
                    {
                        di3.Image = dice[1];
                    }
                    //sets dice face to 3
                    if (diceRoll[2] == 3)
                    {
                        di3.Image = dice[2];
                    }
                    //sets dice face to 4
                    if (diceRoll[2] == 4)
                    {
                        di3.Image = dice[3];
                    }
                    //sets dice face to 5
                    if (diceRoll[2] == 5)
                    {
                        di3.Image = dice[4];
                    }
                    //sets dice face to 6
                    if (diceRoll[2] == 6)
                    {
                        di3.Image = dice[5];
                    }
                    dRoll[2] = false;//sets this if statement to false as to not run
                }
                //if the dice is not held
                if (dRoll[3] == true)
                {
                    diceRoll[3] = random.Next(1, 7);//rolls the dice
                    //sets d face to 1
                    if (diceRoll[3] == 1)
                    {
                        di4.Image = dice[0];
                    }
                    //sets d face to 2
                    if (diceRoll[3] == 2)
                    {
                        di4.Image = dice[1];
                    }
                    //sets dface to 3
                    if (diceRoll[3] == 3)
                    {
                        di4.Image = dice[2];
                    }
                    //sets dface to 4
                    if (diceRoll[3] == 4)
                    {
                        di4.Image = dice[3];
                    }
                    //sets dface to 5
                    if (diceRoll[3] == 5)
                    {
                        di4.Image = dice[4];
                    }
                    //sets dface to 6
                    if (diceRoll[3] == 6)
                    {
                        di4.Image = dice[5];
                    }
                    dRoll[3] = false;
                }
                //if the dice is not held
                if (dRoll[4] == true)
                {
                    diceRoll[4] = random.Next(1, 7);//rolls the dice
                    //sets dface to 1
                    if (diceRoll[4] == 1)
                    {
                        di5.Image = dice[0];
                    }
                    //sets dface to 2
                    if (diceRoll[4] == 2)
                    {
                        di5.Image = dice[1];
                    }
                    //sets dface to 3
                    if (diceRoll[4] == 3)
                    {
                        di5.Image = dice[2];
                    }
                    //sets dface to 4
                    if (diceRoll[4] == 4)
                    {
                        di5.Image = dice[3];
                    }
                    //sets dface to 5
                    if (diceRoll[4] == 5)
                    {
                        di5.Image = dice[4];
                    }
                    //sets dface to 6
                    if (diceRoll[4] == 6)
                    {
                        di5.Image = dice[5];
                    }
                    dRoll[4] = false;//sets this dice roll to false
                }
            }
            calculator();//cals the calculator function
        }
        //this is the calculator function, it contains all the calculations done in the code(except for a samll few)
        private void calculator()
        {
            //sets the array to zero(tscore)
            for(int i = 0; i < tScore.Length; i++)
            {
                tScore[i] = 0;
            }
            //sets the array to zero(fscore)
            for (int i = 0; i < fScore.Length; i++)
            {
                fScore[i] = 0;
            }
            //sets the array to zero(cscore)
            for (int i = 0; i < cScore.Length; i++)
            {
                cScore[i] = 0;
            }
            //sets the array to zero(yscore)
            for (int i = 0; i < yScore.Length; i++)
            {
                yScore[i] = 0;
            }
            //sets the array to zero(sscore)
            for (int i = 0; i < sScore.Length; i++)
            {
                sScore[i] = 0;
            }
            //sets the array to zero(lscore)
            for (int i = 0; i < lScore.Length; i++)
            {
                lScore[i] = 0;
            }
            //sets the array to zero(hscore)
            for (int i = 0; i < hScore.Length; i++)
            {
                hScore[i] = 0;
            }
            /*if the stored boolean is false set the score of this point in the array to zero(same all 12 of the next if statemets, they are used to 
            reset the values to zero on every role so a value of zero is shown if the score is empty after the role)*/
            if (stored[0] == false)
            {
                score[0] = 0;
            }
            if (stored[1] == false)
            {
                score[1] = 0;
            }
            if (stored[2] == false)
            {
                score[2] = 0;
            }
            if (stored[3] == false)
            {
                score[3] = 0;
            }
            if (stored[4] == false)
            {
                score[4] = 0;
            }
            if (stored[5] == false)
            {
                score[5] = 0;
            }
            if (stored[6] == false)
            {
                score[8] = 0;
            }
            if (stored[7] == false)
            {
                score[9] = 0;
            }
            if (stored[8] == false)
            {
                score[10] = 0;
            }
            if (stored[9] == false)
            {
                score[11] = 0;
            }
            if (stored[10] == false)
            {
                score[12] = 0;
            }
            if (stored[11] == false)
            {
                score[13] = 0;
            }
            if (stored[12] == false)
            {
                score[14] = 0;
            }
            /*this for loop is used to calculate what value the ones twos threes etc. are equal to, 
             also used to see what value is displayed on the dice for other calculations*/
            for (int i = 0; i < diceRoll.Length; i++)
            {
                //if the dice is one add points to the ones
                if (diceRoll[i] == 1 && stored[0] == false)
                {
                    score[0]++;
                }
                //if the dice is two add poits to the twos
                if (diceRoll[i] == 2 && stored[1] == false)
                {
                    score[1]++;
                }
                //if the dice is 3 add points to the threes
                if (diceRoll[i] == 3 && stored[2] == false)
                {
                    score[2]++;
                }
                //if the dice is 4 add points to the fours
                if (diceRoll[i] == 4 && stored[3] == false)
                {
                    score[3]++;
                }
                //if the dice is 5 add points to the fives
                if (diceRoll[i] == 5 && stored[4] == false)
                {
                    score[4]++;
                }
                //if the dice is 6 add points to the sixes
                if (diceRoll[i] == 6 && stored[5] == false)
                {
                    score[5]++;
                }
                //if any of the dice are one add to the dice arrays for the other calculations
                if (diceRoll[i] == 1)
                {
                    tScore[0]++;
                    fScore[0]++;
                    cScore[0]++;
                    yScore[0]++;
                    sScore[0]++;
                    lScore[0]++;
                    hScore[0]++;
                }
                //if any of the dice are two add to the dice arrays for the other calculations
                if (diceRoll[i] == 2)
                {
                    tScore[1]++;
                    fScore[1]++;
                    cScore[1]++;
                    yScore[1]++;
                    sScore[1]++;
                    lScore[1]++;
                    hScore[1]++;
                }
                //if any of the dice are three add to the dice arrays for the other calculations
                if (diceRoll[i] == 3)
                {
                    tScore[2]++;
                    fScore[2]++;
                    cScore[2]++;
                    yScore[2]++;
                    sScore[2]++;
                    lScore[2]++;
                    hScore[2]++;
                }
                //if any of the dice are four add to the dice arrays for the other calculations
                if (diceRoll[i] == 4)
                {
                    tScore[3]++;
                    fScore[3]++;
                    cScore[3]++;
                    yScore[3]++;
                    sScore[3]++;
                    lScore[3]++;
                    hScore[3]++;
                }
                //if any of the dice are five add to the dice arrays for the other calculations
                if (diceRoll[i] == 5)
                {
                    tScore[4]++;
                    fScore[4]++;
                    cScore[4]++;
                    yScore[4]++;
                    sScore[4]++;
                    lScore[4]++;
                    hScore[4]++;
                }
                //if any of the dice are six add to the dice arrays for the other calculations
                if (diceRoll[i] == 6)
                {
                    tScore[5]++;
                    fScore[5]++;
                    cScore[5]++;
                    yScore[5]++;
                    sScore[5]++;
                    lScore[5]++;
                    hScore[5]++;
                }
            }
            //if 3 of the same dice are displayed
            if(tScore[0] >= 3 && stored[6] == false || tScore[1]*2 >= 6 && stored[6] == false || tScore[2]*3 >= 9 && stored[6] == false || tScore[3]*4 >= 12 && stored[6] == false || tScore[4]*5 >= 15 && stored[6] == false || tScore[5]*6 >= 18 && stored[6] == false )
            {
                //sets a point in the score array to all values added together
                score[8] = tScore[0] + tScore[1]*2 + tScore[2]*3 + tScore[3]*4 + tScore[4]*5 + tScore[5]*6;
            }
            //if 4 of the same dice are displayed
            if (fScore[0] >= 4 && stored[7] == false || fScore[1]*2 >= 8 && stored[7] == false || fScore[2]*3 >= 12 && stored[7] == false || fScore[3]*4 >= 16 && stored[7] == false || fScore[4]*5 >= 20 && stored[7] == false || fScore[5]*6 >= 24 && stored[7] == false )
            {
                //adds everything together
                score[9] = fScore[0] + fScore[1]*2 + fScore[2]*3 + fScore[3]*4 + fScore[4]*5 + fScore[5]*6;
            }
            //if chances is not already stored
            if (stored[8] == false)
            {
                //sets a point in the score array to everything added together
                score[10] = cScore[0] + cScore[1] * 2 + cScore[2] * 3 + cScore[3] * 4 + cScore[4] * 5 + cScore[5] * 6;
            }
            //if all the die faces are the same
            if (yScore[0] >= 5 && stored[9] == false || yScore[1] * 2 >= 10 && stored[9] == false || yScore[2] * 3 >= 15 && stored[9] == false || yScore[3] * 4 >= 20 && stored[9] == false || yScore[4] * 5 >= 25 && stored[9] == false || yScore[5] * 6 >= 30 && stored[9] == false)
            {
                score[11] = 50;//sets this point in the score array to 50
            }
            //if there are 4 consecutive faces
            if (sScore[0] >= 1 && sScore[1] >= 1 && sScore[2] >= 1 && sScore[3] >= 1 && stored[10] == false || sScore[1] >= 1 && sScore[2] >= 1 && sScore[3] >= 1 && sScore[4] >= 1 && stored[10] == false || sScore[2] >= 1 && sScore[3] >= 1 && sScore[4] >= 1 && sScore[5] >= 1 && stored[10] == false)
            {
                score[12] = 30;//sets this point in score array to 30
            }
            //if there are 5 consecutive faces
            if (lScore[0] == 1 && lScore[1] == 1 && lScore[2] == 1 && lScore[3] == 1 && lScore[4] == 1 && stored[11] == false || lScore[1] == 1 && lScore[2] == 1 && lScore[3] == 1 && lScore[4] == 1 && lScore[5] == 1 && stored[11] == false)
            {
                score[13] = 40;//sets this point in the array to 40
            }
            //if three of the dice faces are the same(nested if statments used for full house calc)
            if (hScore[0] == 3 && stored[12] == false || hScore[1] == 3 && stored[12] == false || hScore[2] == 3 && stored[12] == false || hScore[3] == 3 && stored[12] == false || hScore[4] == 3 && stored[12] == false || hScore[5] == 3 && stored[12] == false )
            {
                //if 2 of the dice faces are the same
                if (hScore[0] == 2 && stored[12] == false || hScore[1] == 2 && stored[12] == false || hScore[2] == 2 && stored[12] == false || hScore[3] == 2 && stored[12] == false || hScore[4] == 2 && stored[12] == false || hScore[5] == 2 && stored[12] == false)
                {
                    score[14] = 25;//sets this point in the array to 25
                }
            }
            //next thirteen lines of code display the scores in their designated label
            label17.Text = "" + score[0];
            label15.Text = "" + score[1]*2;
            label13.Text = "" + score[2]*3;
            label11.Text = "" + score[3]*4;
            label9.Text = "" + score[4]*5;
            label7.Text = "" + score[5]*6;
            label32.Text = "" + score[8];
            label30.Text = "" + score[9];
            label22.Text = "" + score[10];
            label20.Text = "" + score[11];
            label26.Text = "" + score[12];
            label24.Text = "" + score[13];
            label28.Text = "" + score[14];
        }
        //this is the click events fot the ones label
        private void label17_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
           if(canPressed == true)
            {
                label17.BackColor = Color.Red;//sets label color to red
                roll = 0;//resets rolls
                //resets roll text
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                //resets all dice rolls
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //checks if the total can be displayed, checks if all values are stored
                if (stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true)
                {
                    score[6] = score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6;//adds all the scored together
                    //if the total score is over 63 sets bonus
                    if (score[6] >= 63)
                    {
                        score[7] = 35;//sets bonus score to score array
                    }
                    label5.Text = "" + score[6];//sets total text
                    label3.Text = "" + score[7];//sets bonus text
                }
                //if the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //adds together all the scores
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//sets total text
                }
                canPressed = false;//sets all other labels to false
                stored[0] = true;//locks in the ones value
            }
        }
        //this is the click events for the twos label
        private void label15_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if(canPressed == true)
            {
                label15.BackColor = Color.Red;//sets the label to red
                roll = 0;//resets the rolls
                //resetls to roll text
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                //resets dice rolling
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //checks if the top of tabel is filled
                if (stored[0] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true)
                {
                    //adds together the top of the tabel
                    score[6] = score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6;
                    //if the score is larger than 53
                    if (score[6] >= 63)                       
                    {
                        score[7] = 35;
                    }
                    //sets bonus and total text
                    label5.Text = "" + score[6];
                    label3.Text = "" + score[7];
                }
                //if the table is comepletly filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //adds together all the scores
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//sets total label text
                }
                canPressed = false;//sets all the other label presses to false
                stored[1] = true;//locks in this value
            }
        }
        //this is the click events fot the threes label
        private void label13_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if(canPressed == true)
            {
                label13.BackColor = Color.Red;//sets label color to red
                roll = 0;//resets rolls
                //resets roll text
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                //resets the dice rolls
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the top of the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[3] == true && stored[4] == true && stored[5] == true)
                {
                    //adds to top of the tabel together
                    score[6] = score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6;
                    //if the score is larger that 63
                    if (score[6] >= 63)
                    {
                        score[7] = 35;
                    }
                    //sets total and bonus texts
                    label5.Text = "" + score[6];
                    label3.Text = "" + score[7];
                }
                //if the tabel is comepletly filled
                if (stored[0] == true && stored[1] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //adds the table up and sets the total score
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays total
                }
                canPressed = false;//sets other labels not able to be pressed
                stored[2] = true;//sets this value to locked
            }
        }
        //this is the click event for the fours
        private void label11_Click(object sender, EventArgs e)
        {
            //if this label can be pressed
            if(canPressed == true)
            {
                label11.BackColor = Color.Red;//sets label color to red
                roll = 0;//resets rolls
                //resets roll text
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                //resets dice rolls
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the top of the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[4] == true && stored[5] == true)
                {
                    //sets the total for the top
                    score[6] = score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6;
                    //if the total is larger than 63 set bonus to 35 points
                    if (score[6] >= 63)
                    {
                        score[7] = 35;
                    }
                    //sets total and bonus texts
                    label5.Text = "" + score[6];
                    label3.Text = "" + score[7];
                }
                //if the tabel is completly filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //adds up everything in the tabel
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays total
                }
                canPressed = false;//sets other labels to be non pressable
                stored[3] = true;//locks in value
            }
        }
        //this si the click event for the fives
        private void label9_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if(canPressed == true)
            {
                label9.BackColor = Color.Red;//sets the label to red
                roll = 0;//resets rolls
                //resets roll text
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                //resets the dice rolls
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the top of the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[5] == true)
                {
                    //adds up the top of the tabel and makes it equal to score
                    score[6] = score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6;
                    //if the total is equal to or larger than 63 set bonus to 35
                    if (score[6] >= 63)
                    {
                        score[7] = 35;
                    }
                    //sets the bonus and total texts
                    label5.Text = "" + score[6];
                    label3.Text = "" + score[7];
                }
                //if the tabel is completly filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //adds up all avalues on the tables
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays total
                }
                canPressed = false;//sets other labels to un pressable
                stored[4] = true;//sets this value to locked
            }
        }
        //this is the click event fot the sixes
        private void label7_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if(canPressed == true)
            {
                label7.BackColor = Color.Red;//sets label to red
                roll = 0;//resets the rolls
                //resets the roll text
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                //resets the dice rolls
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the top of the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true)
                {
                    //adds the top of the tabel together and sets it to a score int var
                    score[6] = score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6;
                    //if the score is greater of equal to 63 set bonus to 35
                    if (score[6] >= 63)
                    {
                        score[7] = 35;
                    }
                    //sets bonus and total text
                    label5.Text = "" + score[6];
                    label3.Text = "" + score[7];
                }
                //if the whole table is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //adds together the whole table
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displys the total
                }
                canPressed = false;//sets other labels to bot being able to be pressed
                stored[5] = true;//sets locks this value
            }
        }
        //if this button is pressed resets application
        private void PlayAgain_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
        //this is the three of a kind label click events
        private void label32_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if (canPressed == true)
            {
                label32.BackColor = Color.Red;//sets label to red
                //resets the roll
                roll = 0;
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the whole table is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //add the table together
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays total
                }
                stored[6] = true;//locks in value
                canPressed = false;//stops other labels from being pressed
            }
        }
        //this is the four of a kind label and its click events
        private void label30_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if (canPressed == true)
            {
                label30.BackColor = Color.Red;//sets teh label color to red
                //resets the roll
                roll = 0;
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //adds together everything on the tabel
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score [7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays the total
                }
                stored[7] = true;//locks the score value for this
                canPressed = false;//stops other labels from being pressed after this one
            }
        }
        //this is the chance lable click events
        private void label22_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if (canPressed == true)
            {
                label22.BackColor = Color.Red;//sets the label to red
                //resets roll
                roll = 0;
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the table is full
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //add together all values in the table
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays the total
                }
                stored[8] = true;//locks in value
                canPressed = false;//stops other labels from being pressed after this one
            }
        }
        //this is the yhatzee click events
        private void label20_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if (canPressed == true)
            {
                label20.BackColor = Color.Red;//sets the label color to red
                //resets the roll
                roll = 0;
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the table if fu;;
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //add together all values in the table
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays total score
                }
                stored[9] = true;//lock in this value
                canPressed = false;//stops other labels form being pressed
            }
        }
        //this is the cheat/bonus click events
        private void label3_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if (canPressed == true)
            {
                score[7] = 100000;//sets bonus to 100000
                label3.BackColor = Color.Red;//sets the label to red
                label3.Text = "100000";
                //if the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true && stored[12] == true)
                {
                    //adds everything in the tabel together
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//display total
                }
            }
        }
        //this is the small straight click events
        private void label26_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if (canPressed == true)
            {
                label26.BackColor = Color.Red;//sets label to red
                //resets roll
                roll = 0;
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[11] == true && stored[12] == true)
                {
                    //adds together all values in the tabel
                    score[15] += score[7] + score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays total
                }
                stored[10] = true;//locks in this value
                canPressed = false; //stops other labels from being pressed
            }
        }
        //this is the large straight click events
        private void label24_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if (canPressed == true)
            {
                label24.BackColor = Color.Red;//sets the label color to red
                //resets roll
                roll = 0;
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the table is full
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[12] == true)
                {
                    //adds together all values in the tabel
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays the total
                }
                stored[11] = true;//locks in this value
                canPressed = false;//stops other labels from being pressed
            }
        }
        //this is the full house click events
        private void label28_Click(object sender, EventArgs e)
        {
            //if the label can be pressed
            if (canPressed == true)
            {
                label28.BackColor = Color.Red;//sets the label color to red
                //resets roll
                roll = 0;
                if (roll == 0)
                {
                    rollCount.Text = "You have used 1 of 3 rolls";
                }
                for (int i = 0; i < dRoll.Length; i++)
                {
                    dRoll[i] = true;
                }
                //if the tabel is filled
                if (stored[0] == true && stored[1] == true && stored[2] == true && stored[3] == true && stored[4] == true && stored[5] == true && stored[6] == true && stored[7] == true && stored[8] == true && stored[9] == true && stored[10] == true && stored[11] == true)
                {
                    //adds together evrything in the table
                    score[15] += score[0] + score[1] * 2 + score[2] * 3 + score[3] * 4 + score[4] * 5 + score[5] * 6 + score[7] + score[8] + score[9] + score[10] + score[11] + score[12] + score[13] + score[14];
                    label18.Text = "" + score[15];//displays total
                }
                stored[12] = true;//locks in this value
                canPressed = false;//stops other tabels from being pressed
            }
        }
    }

        
}//end of code
    
    

