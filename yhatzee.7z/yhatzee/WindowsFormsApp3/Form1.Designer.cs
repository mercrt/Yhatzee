﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.di1 = new System.Windows.Forms.Button();
            this.di3 = new System.Windows.Forms.Button();
            this.Roll = new System.Windows.Forms.Button();
            this.di5 = new System.Windows.Forms.Button();
            this.di4 = new System.Windows.Forms.Button();
            this.di2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // di1
            // 
            this.di1.Image = global::WindowsFormsApp3.Properties.Resources.d1;
            this.di1.Location = new System.Drawing.Point(72, 442);
            this.di1.Name = "di1";
            this.di1.Size = new System.Drawing.Size(105, 105);
            this.di1.TabIndex = 0;
            this.di1.UseVisualStyleBackColor = true;
            this.di1.Click += new System.EventHandler(this.di1_Click);
            // 
            // di3
            // 
            this.di3.Image = global::WindowsFormsApp3.Properties.Resources.d3;
            this.di3.Location = new System.Drawing.Point(158, 237);
            this.di3.Name = "di3";
            this.di3.Size = new System.Drawing.Size(105, 105);
            this.di3.TabIndex = 1;
            this.di3.UseVisualStyleBackColor = true;
            this.di3.Click += new System.EventHandler(this.di3_Click);
            // 
            // Roll
            // 
            this.Roll.BackColor = System.Drawing.Color.Red;
            this.Roll.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Roll.Location = new System.Drawing.Point(405, 252);
            this.Roll.Name = "Roll";
            this.Roll.Size = new System.Drawing.Size(162, 75);
            this.Roll.TabIndex = 2;
            this.Roll.Text = "ROLL";
            this.Roll.UseVisualStyleBackColor = false;
            this.Roll.Click += new System.EventHandler(this.Roll_Click);
            // 
            // di5
            // 
            this.di5.Image = global::WindowsFormsApp3.Properties.Resources.d5;
            this.di5.Location = new System.Drawing.Point(248, 40);
            this.di5.Name = "di5";
            this.di5.Size = new System.Drawing.Size(105, 105);
            this.di5.TabIndex = 3;
            this.di5.UseVisualStyleBackColor = true;
            this.di5.Click += new System.EventHandler(this.di5_Click);
            // 
            // di4
            // 
            this.di4.Image = global::WindowsFormsApp3.Properties.Resources.d4;
            this.di4.Location = new System.Drawing.Point(72, 40);
            this.di4.Name = "di4";
            this.di4.Size = new System.Drawing.Size(105, 105);
            this.di4.TabIndex = 4;
            this.di4.UseVisualStyleBackColor = true;
            this.di4.Click += new System.EventHandler(this.di4_Click);
            // 
            // di2
            // 
            this.di2.Image = global::WindowsFormsApp3.Properties.Resources.d2;
            this.di2.Location = new System.Drawing.Point(248, 442);
            this.di2.Name = "di2";
            this.di2.Size = new System.Drawing.Size(105, 105);
            this.di2.TabIndex = 5;
            this.di2.UseVisualStyleBackColor = true;
            this.di2.Click += new System.EventHandler(this.di2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 615);
            this.Controls.Add(this.di2);
            this.Controls.Add(this.di4);
            this.Controls.Add(this.di5);
            this.Controls.Add(this.Roll);
            this.Controls.Add(this.di3);
            this.Controls.Add(this.di1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button di1;
        private System.Windows.Forms.Button di3;
        private System.Windows.Forms.Button Roll;
        private System.Windows.Forms.Button di5;
        private System.Windows.Forms.Button di4;
        private System.Windows.Forms.Button di2;
    }
}

